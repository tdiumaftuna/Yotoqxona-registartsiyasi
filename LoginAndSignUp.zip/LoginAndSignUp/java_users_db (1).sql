-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2024 at 11:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `java_users_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `ism` varchar(127) NOT NULL,
  `familiya` varchar(127) NOT NULL,
  `xona_raqami` varchar(127) NOT NULL,
  `tolov_miqdori` varchar(127) NOT NULL,
  `qarzi_miqdori` varchar(127) NOT NULL,
  `telefon` varchar(127) NOT NULL,
  `yashash_manzili` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `ism`, `familiya`, `xona_raqami`, `tolov_miqdori`, `qarzi_miqdori`, `telefon`, `yashash_manzili`) VALUES
(4, 'Gulnoza ', 'Qodirova', '3.06', '1.200.000', '0', '+998908493531', 'Fargona viloyati'),
(27, 'Gulnoza ', 'Qodirova', '3.06', '1.200.000', '0', '+998908493531', 'Fargona viloyati'),
(28, 'Maftuna', 'Yigitaliyeva', '117', '1200000', '0', '+998994997364', 'Fargona viloyati'),
(29, 'Rayxona', 'Xusanova', '3.06', '1.200.000', '0', '+998978322307', 'Fargona viloyati'),
(32, 'Rayxona', 'Xusanova', '3.06', '1.200.000', '0', '+998978322307', 'Fargona viloyati');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(127) NOT NULL,
  `email` varchar(127) NOT NULL,
  `password` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`) VALUES
(3, 'alisher', 'alisherismailov1991@gmail.com', 'ali199104'),
(6, 'Maftuna Yigitaliyeva', '0421', '2004');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
